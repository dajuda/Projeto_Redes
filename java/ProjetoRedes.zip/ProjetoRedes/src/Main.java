public class Main {
	
	public static void main(String argv[]) throws Exception {
		
		P2P servidor = new P2P();
		Thread s = new Thread(servidor);
		s.start();
		
	}
	
}

