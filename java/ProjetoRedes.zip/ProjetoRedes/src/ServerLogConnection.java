import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ServerLogConnection {
    private String host;
    private String user;
    private String pass;
    private String database;
    
    public Connection conn;
  
    public ServerLogConnection( String host, String database, String user, String pass ) {
        this.pass = pass;
        this.user = user;
        this.host = host;
        this.database = database;
    }
    
    /**
     * Conecta com o banco de dados
     */
    public boolean connect() {
        boolean isConnected = false;
        String url = "jdbc:mysql://"+host+"/"+database+"?"+"user="+user +"&password="+pass;
              
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            this.conn = DriverManager.getConnection(url);
            isConnected = true;
        } catch( SQLException e ) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            isConnected = false;
        } catch ( ClassNotFoundException e ) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            isConnected = false;
        } catch ( InstantiationException e ) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            isConnected = false;
        } catch ( IllegalAccessException e ) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            isConnected = false;
        }
        
        return isConnected;
    }
    
    public int insert(String query) {
        
        int result = -1;

        try {
        	Statement st = this.conn.createStatement();
            result = st.executeUpdate(query);
        } catch ( SQLException e ) {
            e.printStackTrace();
        }
        
        return result;
    }
    
    public void close(){
        try {
            this.conn.close();
        } catch ( SQLException e ) {
            e.printStackTrace();
        }
    }

    
}
