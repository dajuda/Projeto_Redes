import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;
import java.util.UUID;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


/**
 * PROJETO REDES DE COMPUTADORES - SCC0540 - BSI 1� SEMESTRE 2015
 * 
 * RODRIGO VENANCIO				8626191
 * CAIN� DE SOUZA D'AJUDA		8531511
 *
 */

public class P2P implements Runnable {
	
	private final static int PORT = 8090;			/* Porta padr�o */
	private ServerSocket serverSocket = null;		/* Socket que recebe as conex�es desse cliente/servidor P2P */
	private ArrayList<Socket> allClients;			/* Lista que guarda os clientes conectados neste cliente/servidor P2P */
	private HashSet<String> receivedMessagesIds;	/* Hash que guarda as ids das mensagens recebidas neste cliente/servidor P2p */
	
	// Construtor vazio
	public P2P(){}

	@Override
	public void run() {
		// Inicializa Lista de Peers conectados e o HashSet com as mensagens ja recebidas
		allClients = new ArrayList<Socket>();
		receivedMessagesIds = new HashSet<String>();
		
		// Seta o "server" deste peer
		setServer();
		
		System.out.println("Comandos:");
		System.out.println("\tConectar: \'#IP\'");
		System.out.println("\tDesconectar: \'-IP\'");
		System.out.println("\tMensagem privada: \'@IP\', pressione enter e digite a mensagem.");
		System.out.println("\tPeers conectados: \'*\'");
		System.out.println("\tSair: \'q\'");
		System.out.println("--------------------------------------------------------------------");
		System.out.println();
		
		// Le os inputs do usuario
		while(true) {
			Scanner scanner = new Scanner(System.in);
			String text = scanner.nextLine();
			
			// #ip - Conecta com o ip fornecido
			if (text.startsWith("#")){
				handleAddClient(text.replace("#", ""));
			
			// @ip - Manda mensagem privada para ip especificado
			} else if (text.startsWith("@")){
				HandleSendText t = new HandleSendText(text.replace("@", ""), scanner.nextLine(), -1);
				t.start();
				
			// * - mostra todos os peers conectados
			} else if (text.equals("*")){
				showConnectedPeers();
				
			// -ip - Desconecta o ip fornecido
			} else if (text.startsWith("-")){
				disconnectPeer(text.replace("-", ""));
				
			// \q - Fecha o cliente/servidor
			} else if (text.equals("q")) {
				System.out.println("Voc� saiu.");
				System.exit(0);
				
			// Mensagem comum, enviada a todos
			} else {
				HandleSendText t = new HandleSendText(null, text, -1);
				t.start();
			}
		}
	}

	/**
	 * Desconecta um peer a partir de um ip
	 */
	private void disconnectPeer(String ip) {
		boolean removed = false;
		for (int i = 0; i < allClients.size(); i++) {
			if (allClients.get(i).getInetAddress().toString().replace("/", "").equals(ip)){
				// Notifica os outros peers de que este peer ira desconectar
				HandleSendText t = new HandleSendText(ip, "!disconnected", i);
				t.start();
				removed = true;
			}	
		}
		if (!removed) System.out.println("Peer n�o encontrado.");
	}

	/**
	 * Mostra todos os peers conectados a esse peer
	 */
	private void showConnectedPeers() {
		if (allClients.size() == 0) {
			System.out.println("Nenhum peer conectado.");
		} else {
			System.out.println("Peers conectados:");
			for (Socket socket : allClients) {
				System.out.println("\t(\'" + socket.getInetAddress().toString() + "\', " + socket.getPort() + ")" );
			}
		}
	}
	
	/**
	 * Cria o server deste peer e comeca a ouvir conexoes de outros peers
	 */
	public void setServer(){
		try {
			// Verifica se o server esta ativo e realiza o desativamento
			if (serverSocket != null) {
				serverSocket.close();
				serverSocket = null;
			} 
			
			// Cria o socket do server com a porta padr�o
//			serverSocket = new ServerSocket(PORT);
//			System.out.println("Servidor ouvindo na porta: " + PORT);
			
			String ip = "127.0.0.1";
			serverSocket = new ServerSocket();
			serverSocket.bind(new InetSocketAddress(ip, PORT));
			System.out.println("Server listening on: " + ip + ":" + PORT);
			
			// Com o server setado, come�amos a ouvir conex�es de outros peers
			ListenClientsThread t = new ListenClientsThread();
			t.start();
			
			
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Erro em inicializar o servidor.");
		}
	}
	
	/**
	 * Ouvindo novas conex�es de peers
	 */
	public class ListenClientsThread extends Thread {

	    public void run(){
	    	try {
		    	while (true) {		   
		    		// Aceita a conex�o
					Socket clientSocket = serverSocket.accept();
					System.out.println("Novo cliente conectado (" + String.valueOf(clientSocket.getInetAddress()).replace("/", "") + ")");
					
					// Adiciona o socket client na ArrayList dos peers conectados
					addClient(clientSocket);
					
					// Iniciliaza a thread que ouve o que este cliente escreve e manda para os peers conectados
					HandleClientMessagesThread t = new HandleClientMessagesThread(clientSocket,
							clientSocket.getInetAddress().getHostAddress(),
							PORT);
					t.start();
				}
	    	} catch (IOException e) {
				System.out.println("IOException");
				try {
					serverSocket.close();
					System.out.println("ServerSocket fechado.");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
	    }
	}
	
	/**
	 * Thread que fica ouvindo o input do cliente 
	 * e manda para os clientes conectados
	 */
	public class HandleSendText extends Thread {
		String message;
		String to;
		int indexDisconnected;
		
		public HandleSendText(String to, String message, int indexDisconnected) {
			this.message = message;
			this.to = to;
			this.indexDisconnected = indexDisconnected;
		}
		
	    public void run(){
	    	try {				
				for (Socket s : allClients){
					if (to == null) {
						to = "all";
					}
					
					GsonBuilder builder = new GsonBuilder();
					Gson gson = builder.create();
					ChatInfo chatInfo = new ChatInfo(serverSocket.getInetAddress().getHostAddress(),
							to, message, UUID.randomUUID().toString());
					String json = gson.toJson(chatInfo);
					
					PrintWriter out = new PrintWriter(s.getOutputStream());
					out.println(json);
					out.flush();
				}
				
				// Verifica se recebeu um id do peer desconecado, e o finalmente o remove e fecha a conexao
				if (indexDisconnected != -1) {
					allClients.get(indexDisconnected).close();
					allClients.remove(indexDisconnected);
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
	}
	
	/**
	 * Thread que fica ouvindo mensagens recebidas 
	 * do socket do peer conectado
	 */
	public class HandleClientMessagesThread extends Thread {
		Socket clientSocket;
		String address;
		int port;
		
		public HandleClientMessagesThread(Socket clientSocket, String address, int port) {
			this.clientSocket = clientSocket;
			this.address = address;
			this.port = port;
		}
		
	    public void run(){
	    	while (true) {
	    		try {
	    			// InputStream do socket deste peer
					BufferedReader received = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
					// Recebe o json da mensagem
					String json = received.readLine();
					
					if (json != null) {
						Gson gson = new Gson();
						ChatInfo chatInfo = gson.fromJson(json, ChatInfo.class);
						
						// Checa se esta mensagem j� foi recebida 
						if (!receivedMessagesIds.contains(chatInfo.getId())) {
							
							// Se n�o foi, adiciona ela as mensagens recebidas
							receivedMessagesIds.add(chatInfo.getId());
							
							// Verifica se a mensagem recebida � global
							if (chatInfo.getTo().equals("all")) {
								
								// Imprime a mensagem recebida
								System.out.println(chatInfo.getFrom() + ":" + chatInfo.getData());
							}
							
							// Verifica se a mensagem recebida eh feedback de desconeccao
							if (chatInfo.getData().equals("!disconnected")) {
								disconnectPeer(chatInfo.getFrom());
							}
							
							// Ve se a mensagem recebida � privada para este peer
							if (chatInfo.getTo().equals(serverSocket.getInetAddress().getHostAddress()) &&
									!chatInfo.getData().equals("!disconnected")) {
								System.out.println("(Privado) " + chatInfo.getFrom() + ":" + chatInfo.getData());
								
							// Se nao for privada
							} else {
								// Replica a mensagem para todos os peers conectados (menos o que enviou)
								try {				
									for (Socket s : allClients){	
										if (s != clientSocket) { 
											PrintWriter out = new PrintWriter(s.getOutputStream());
											out.println(json);
											out.flush();
										}
									}
								} catch (IOException e) { e.printStackTrace(); }
							}
						}
					}
					
				} catch (IOException e) {
					System.out.println("Cliente desconectado (" + address.replaceAll("/", "") + ")");
					allClients.remove(clientSocket);
					try {
						clientSocket.close();
					} catch (IOException e1) {
					}
					break;
				} 
	    	}
	    }
	}
	
	/**
	 * Adiciona o peer na ArrayList dos peers conectados 
	 */
	public void addClient(Socket client){
		System.out.println("Conectado ao cliente (" + String.valueOf(client.getInetAddress()).replace("/", "") + ")");
		allClients.add(client);
	}
	
	/**
	 * Cria o socket do novo peer e come�a a ouvir mensagens vindas do mesmo
	 */
	public void handleAddClient(String clientAddress) {
		try {
			// Cria Socket deste novo Peer
			Socket clientSocket = new Socket(clientAddress, PORT);
			
			// Adiciona-o na lista de peers conectados
			addClient(clientSocket);
			
			// Inicializa a thread que ouve mensagens enviadas por este novo peer
			HandleClientMessagesThread t = new HandleClientMessagesThread(clientSocket,
					clientSocket.getInetAddress().getHostAddress(), PORT);
			t.start();
		} catch (Exception e) {
			System.out.println("");
			System.out.println("Peer inexistente.");
			// e.printStackTrace();
		}
	}
	
	public static void sendLog(String from, String to, String message){
        Date dt = new Date();
        SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentTime = sdf.format(dt);
        String query = "INSERT INTO Grupo11_Log values ('" + from + "', '" + to + "', '" 
                + message + "', '" + currentTime + "');";
        ServerLogConnection conn = new ServerLogConnection("node01", "p2p_bsi", "bsi", "bsi#2015");
        conn.connect();
        conn.insert(query);
        conn.close();
    }
	
}